package com.reveture.project2.exception;

public class CustomException extends Exception {
    public CustomException() {
        super();
    }

    public CustomException(String msg) {
        super(msg);
    }
}
